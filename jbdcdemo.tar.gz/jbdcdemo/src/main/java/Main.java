public class Main {

    public static void main(String[] args) {


        String expertise = "kohwj";

        //Filling-out process could be made interactive, but the following is sufficient

        //SQL injections are not possible, since there's no input (tadaa)
        //What perhaps would prevent users from injecting SQL code, is to always scan user input for SQL keywords.
        //
        //In our case, there would be no text input fields when a Patient fills out a form (Sliders/radio buttons for form input), except for entering the Patient ID at the beginning. This would have to be trimmed, and casted to Int, before any SQL-calls are made. Fairly simple with Ints, perhaps it is more complex with more general text input fields.

        int answer1 = 3;
        int answer2 = 4;
        int answer3 = 1;

        String query1 = "Select * from Employee e where e.EmployeeID = 72";
        String query2 = "Select *" +
                "from Doctor d join Expertise e" +
                "where d.EmployeeID = e.Employee_EmployeeID AND" +
                "e.Title = " + expertise;
        String query3 = "";

        MySQLConnection.printResultSet(MySQLConnection.executeFromString(query1));
        MySQLConnection.printResultSet(MySQLConnection.executeFromString(query2));
        MySQLConnection.printResultSet(MySQLConnection.executeFromString(query3));


    }
}
