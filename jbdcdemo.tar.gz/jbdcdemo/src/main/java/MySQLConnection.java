import javax.xml.transform.Result;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MySQLConnection {

    private static Connection connection = null;

    private static String dbHost = "62.193.53.284";

    private static String dbPort = "3306";

    private static String database = "sakila";

    private static String dbUser = "simon";

    private static String dbPassword = "toor";

    private MySQLConnection() {
        try {

            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://" + dbHost + ":"
                    + dbPort + "/" + database + "?" + "user=" + dbUser + "&"
                    + "password=" + dbPassword);
        } catch (ClassNotFoundException e) {
            System.out.println("Driver not found");
        } catch (SQLException e) {
            System.out.println("Connect failed");
        }
    }

    private static Connection getInstance()
    {
        if(connection == null)
            new MySQLConnection();
        return connection;
    }

    /**
     * Schreibt die Namensliste in die Konsole
     */
    public static ResultSet executeFromString(String sqlString){
        connection = getInstance();

        Statement query;
        try {
            query = connection.createStatement();

            return query.executeQuery(sqlString);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;

    }

    public static void printResultSet(ResultSet rs){

            if(rs == null) return;

            try {
                while(rs.next()) {
                    System.out.println(rs.getString(1));
                    System.out.println(rs.getString(2));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

    }


}